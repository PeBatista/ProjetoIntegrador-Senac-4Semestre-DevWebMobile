<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">

        <span class="color-brand"><h1><i class="fa-solid fa-circle-info"></i> <?php echo e($vacina->nome_vacina); ?></h1></span>


        <div class="card mt-4">
            <div class="card-body">
                <p><strong>Sobre: </strong> <?php echo e($vacina->descricao); ?></p>
                <br>
                <p><strong>Onde encontrar: </strong><?php echo e($vacina->local_aplicacao); ?></p>
            </div>
        </div>
        
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjetoIntegradorAppHealthTrack\resources\views/vacinas/show.blade.php ENDPATH**/ ?>