<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/styles_sbadmin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/font-awesome/css/all.min.css')); ?>" rel="stylesheet">

    <title><?php echo e(env('APP_BRAND')); ?></title>
</head>
<body class="sb-nav-fixed">

  <?php if(Route::current()->getName() != 'pessoa.cadastar'): ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light mb-3" id="navbar">
        <div class="container-fluid">
          <button class="navbar-toggler color-brand" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span><span> Menu</span>
          </button>
          <div class="d-flex justify-content-end m-1">
            <a href="<?php echo e(route('pessoa.exibir', ['pessoa' => session('id_pessoa')])); ?>" class="btn btn-link btn-sm btn-menu"><i class="fa-regular fa-user"></i></a>
            <?php if(Route::current()->getName() != 'vacina.listar'): ?>
              <a href="<?php echo e(route('vacina.listar')); ?>" class="btn btn-link btn-sm btn-menu"><i class="fa-solid fa-arrow-left"></i></a>
            <?php endif; ?>
          </div>
          <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
            <ul class="navbar-nav me-auto mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('vacina.listar')); ?>">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('app.index')); ?>">Sair</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    <?php endif; ?>
    <div class="container">

        <div class="row">


                <?php echo $__env->yieldContent('content'); ?>

        </div>

    </div>







    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts_sbadmin.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/font-awesome/js/all.min.js')); ?>"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\ProjetoIntegradorAppHealthTrack\resources\views/layouts/default.blade.php ENDPATH**/ ?>