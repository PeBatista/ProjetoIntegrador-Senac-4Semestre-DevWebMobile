<?php $__env->startSection('content'); ?>
    <div class="col-12 d-flex flex-column justify-content-center">

        <span class="color-brand mb-3 mt-5 text-center">
            <h1><i class="fa-regular fa-pen-to-square"></i> Cadastrar</h1>
        </span>

        
        <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <div class="row">
            <div class="col-12 mb-4">
                <form action="<?php echo e(route('pessoa.armazenar')); ?>" method="POST">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>

                    <input type="text" class="form-control mb-4" name="nome" id="nome" placeholder="Nome Completo" value="<?php echo e(old('nome')); ?>" required>

                    <input type="text" class="form-control mb-4" name="cpf" id="cpf" placeholder="CPF formato 000.000.000-99" value="<?php echo e(old('cpf')); ?>" required>

                    <input type="text" class="form-control mb-4" name="endereco" id="endereco" placeholder="Endereço Completo" value="<?php echo e(old('endereco')); ?>" required>

                    <input type="text" class="form-control mb-4" name="data_nascimento" id="data_nascimento" placeholder="Data de Nascimento" value="<?php echo e(old('data_nascimento')); ?>" required>

                    <input type="text" class="form-control mb-4" name="cep" id="cep" placeholder="CEP" value="<?php echo e(old('cep')); ?>" required>

                    <input type="text" class="form-control mb-4" name="cns" id="cns" placeholder="CNS" value="<?php echo e(old('cns')); ?>" required>

                    <input type="text" class="form-control mb-4" name="rg" id="rg" placeholder="Registro Geral - RG" value="<?php echo e(old('rg')); ?>" required>

                    <input type="password" class="form-control mb-4" name="senha" id="senha" placeholder="Senha" >

                    <input type="password" class="form-control mb-4" name="valida_senha" id="valida_senha" placeholder="Confirme Senha" >

                    <div class="d-flex justify-content-around">
                        <button type="submit" class="btn btn-green fs-5 me-1 w-50">
                            <i class="fa-solid fa-right-to-bracket"></i> 
                            Entrar
                        </button>
                </form>

                <a href="<?php echo e(route('app.index')); ?>" class="btn btn-link btn-sm btn-menu w-50"><i class="fa-solid fa-arrow-left"></i> Voltar</a>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjetoIntegradorAppHealthTrack\resources\views/pessoas/create.blade.php ENDPATH**/ ?>