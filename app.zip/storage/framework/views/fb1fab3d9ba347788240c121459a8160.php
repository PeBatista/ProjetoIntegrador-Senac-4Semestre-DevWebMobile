<?php $__env->startSection('content'); ?>

    <div class="col-12 d-flex flex-column align-items-center">
        <?php $__empty_1 = true; $__currentLoopData = $vacinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('vacina.exibir', ['vacina' => $vacina->id])); ?>" class="box-vacina"
                style="border: 1px solid #359A3C;"><?php echo e($vacina->nome_vacina); ?></a><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-danger" role="alert">
                Nenhuma Vacina Encontrada!
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjetoIntegradorAppHealthTrack\resources\views/vacinas/index.blade.php ENDPATH**/ ?>